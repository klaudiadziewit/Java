public abstract class Figure {
    abstract double calculateArea();
    abstract double calculatePerimeter();
}
