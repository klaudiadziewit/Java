public enum ItemCondition {
    NEW, USED, REFURBISHED;
}
