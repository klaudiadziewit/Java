public interface IPrintable {
    public void print();
}
