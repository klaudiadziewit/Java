import java.util.ArrayList;
import java.util.List;

public class Manual {
    public static void main(String[] args) {
        FulfillmentCenter fulfillmentCenter = new FulfillmentCenter("IKEA",200.0 );
        //i
        Item item1 = new Item("TABLE", 10.0, 3, ItemCondition.NEW);
        Item item2 = new Item("TABLE", 10.0, 3, ItemCondition.NEW);
        Item item3 = new Item("Wardrobe", 10.0, 1, ItemCondition.NEW);
        Item item4 = new Item("Armchair", 10.0, 1, ItemCondition.NEW);
        Item item5 = new Item("Blanket", 0.2, 4, ItemCondition.REFURBISHED);
        Item item6 = new Item("Mug", 0.2, 4, ItemCondition.USED);
        Item item7 = new Item("Blanket", 0.1, 2, ItemCondition.NEW);
        Item item8 = new Item("Blanket", 0.2, 4, ItemCondition.REFURBISHED);
        Item item9 = new Item("Blanket", 170.0, 1, ItemCondition.REFURBISHED);
        Item item10 = new Item("Trolo", 5.0, 1, ItemCondition.REFURBISHED);

        fulfillmentCenter.addProduct(item1);
        fulfillmentCenter.addProduct(item2);
        fulfillmentCenter.addProduct(item3);
        fulfillmentCenter.addProduct(item4);
        fulfillmentCenter.addProduct(item5);
//        fulfillmentCenter.addProduct(item6);
//        fulfillmentCenter.addProduct(item7);
//        fulfillmentCenter.addProduct(item8);
//        fulfillmentCenter.addProduct(item9);
//        fulfillmentCenter.addProduct(item10);

        int newItems = fulfillmentCenter.countByCondition(ItemCondition.NEW);
        //int refurbishedItems = fulfillmentCenter.countByCondition(ItemCondition.REFURBISHED);
        //int usedItems = fulfillmentCenter.countByCondition(ItemCondition.USED);
        System.out.println("There are " + newItems + " items with 'NEW' condition");
        //System.out.println(refurbishedItems);
        //System.out.println(usedItems);
        //fulfillmentCenter.summary();
        //fulfillmentCenter.removeProduct(item1);
        //fulfillmentCenter.getProduct(item1);
        //fulfillmentCenter.getProduct(item2);
        //fulfillmentCenter.removeProduct(item1);

        fulfillmentCenter.getProduct(item1);
        fulfillmentCenter.summary();
        newItems = fulfillmentCenter.countByCondition(ItemCondition.NEW);
        System.out.println("There are " + newItems + " items with 'NEW' condition");

        fulfillmentCenter.sortByAmount();
        fulfillmentCenter.summary();
        fulfillmentCenter.sortByName();
        fulfillmentCenter.summary();


    }
}
